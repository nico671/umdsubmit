# USAGE

Navigate to the root of the project directory in the terminal and enter `umdsubmit` to submit. Enter your UMD Directory ID and password as requested. All data is stored locally.
# USAGE

Navigate to the root of the project directory in the terminal and run the command `umdsubmit`. Enter your UMD Directory ID and password as requested.